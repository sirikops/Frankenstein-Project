/*
Author: Siri Kopparapu
Purpose: This is the driver file for the playgame.html page. It gives the playgame.html page functionality and controls game flow.
*/

//create a character array
var characterArray = ["Victor", "Monster"];

//these are the values that are associated with each player
var character = ""; //which character we got as result of random pick
var score = 0; //based on the answer to the question, this score will change

function randomPick() {
  //the first one prints a decimal
  var rawRandIndex = Math.random() * characterArray.length;
  //the second one prints floored value (i.e. if I have 1.2 I print 1 and if I have 0.6 then I print 0)
  var randIndex = Math.floor(rawRandIndex);
  return randIndex; //returns value
}

var index = randomPick();
// console.log("test: " + characterArray[index]);

//creating a constructor for my player
function player(character, score) {
  this.character = character;
  this.score = score;
}

var myPlayer = new player(characterArray[index], 0);
// console.log("test: " + myPlayer.character);

//creating an array for questions as character "Victor"
var victorQuestions = [
  {
    question: "Do I get an education?",
    answer1: `<input type="radio" name=q1 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q1 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Should I seek a companion?",
    answer1: `<input type="radio" name=q2 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q2 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Do I tell Clerval about the monster?",
    answer1: `<input type="radio" name=q3 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q3 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Justine is on trial. Do I reveal myself?",
    answer1: `<input type="radio" name=q4 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q4 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Should I make the female monster?",
    answer1: `<input type="radio" name=q5 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q5 value=option2>no</input>`,
    points1: 5,
    points2: 3
  }
]

//creating an array of questions as character "monster"
var monsterQuestions = [
  {
    question: "Do I get an education?",
    answer1: `<input type="radio" name=q1 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q1 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Should I seek a companion?",
    answer1: `<input type="radio" name=q2 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q2 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Do I reveal myself to the DeLaceys?",
    answer1: `<input type="radio" name=q3 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q3 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Justine is on trial. Do I reveal myself?",
    answer1: `<input type="radio" name=q4 value=option1>yes</input>`,
    answer2: `<input type="radio" name=q4 value=option2>no</input>`,
    points1: 5,
    points2: 3
  },
  {
    question: "Is my quest for revenge just or not?",
    answer1: `<input type="radio" name=q5 value=option1>yes, this is just</input>`,
    answer2: `<input type="radio" name=q5 value=option2>no, this is unjust</input>`,
    points1: 5,
    points2: 3
  }
]

var victorFates = [
  "You followed the same journey as Victor in the novel. You die a death at the hands of the monster. What would have happened if you just conformed to society?",
  "You revealed yourself at Justine's trial and get the townspeople to believe you. They want you to find the monster and bring him to justice in front of the court. However, out of pity for the monster, you make the female monster. Unable to produce the monster in court, you die by execution.",
  "You reveal your creation of the monster to Clerval and he offers to help you deal with the monster. Together you find the monster and make peace with him through the creation of a female companion. You marry Elizabeth and keep the inheritance.",
  "You create the female monster but this delay in time causes you to lose Elizabeth. Unable to marry and produce an heir, you lose the inheritance."
];

var monsterFates = [
  "As the monster, you come back to the village and reveal yourself to the townspeople as the murderer. You blame Victor on trial, but no one believes you and you die a painful death by execution.",
  "You never reveal yourselves to the DeLaceys. You continue to help them in their everyday lives and slowly learn to forget about Victor and the pain he caused you.",
  "You follow the same path as the monster in the novel. Did you die in the end? No one ever saw you die..."
];

//this is where the fun begins
var form = $(".game-form");

var startBtn = $(".start-game");

var submitBtn = $(".submit-btn");

//populate the form based on the character selected
function initForm(player) {

  if (player.character == "Victor") {
    return victorQuestions;
  }

  else if (player.character == "Monster") {
    return monsterQuestions;
  }

}

function generateForm() {

  // form.removeChild(); //clears the start button
  startBtn.attr("disabled", true);

  //run this to initialize form with player character
  var myBank = initForm(myPlayer);

  for (var i = 0; i < myBank.length; i++) {
    // console.log(myBank[i].question);
    form.append(myBank[i].question);
    form.append(`<br>`);
    form.append(myBank[i].answer1);
    form.append(myBank[i].answer2);
    form.append(`<br>`);
  }

  //test
  // form.append(monsterQuestions[0].question);
  // form.append(monsterQuestions[0].answer1);

  // console.log(questionBank[4].question);
  // form.append(questionBank[4].question);
  form.append(`<br><br>`);
  // form.append(`<button class = "submit-btn">Submit</button>`);
  // submitBtn.style.color = 'Red';
  // console.log("success");
}

startBtn.on("click", generateForm);
// startBtn.attr("disabled", false);

//reveal the character
function revealCharacter() {
  if (myPlayer.character == "Victor") {
    return "Your character is Victor";
    // console.log(reveal);
  } else if (myPlayer.character == "Monster") {
    return "Your character is the Monster";
    // console.log(reveal);
  }
}

//function to calculate score
function calculateScore(event) {

  event.preventDefault();

  // form.append(`<p>clicked!</p>`); //test

  //calculate the quiz score
  var score = 0;

  // Get the selected value for question 1
  var q1Value = document.querySelector('input[name="q1"]:checked').value;

  var q2Value = document.querySelector('input[name="q2"]:checked').value;

  var q3Value = document.querySelector('input[name="q3"]:checked').value;

  var q4Value = document.querySelector('input[name="q4"]:checked').value;

  var q5Value = document.querySelector('input[name="q5"]:checked').value;

  // Calculate the score based on the selected values
  if (q1Value === "option1") {
    score += 5;
  } else if (q1Value == "option2") {
    score += 3;
  }

  if (q2Value === "option1") {
    score += 5;
  } else if (q2Value == "option2") {
    score += 3;
  }

  if (q3Value === "option1") {
    score += 5;
  } else if (q3Value == "option2") {
    score += 3;
  }

  if (q4Value === "option1") {
    score += 5;
  } else if (q4Value == "option2") {
    score += 3;
  }

  if (q5Value === "option1") {
    score += 5;
  } else if (q5Value == "option2") {
    score += 3;
  }

  // Display the score
  form.append(`<p>score: ` + score + `</p>`);

  //reveal the character that you got
  var reveal = revealCharacter();

  form.append(`<p> ` + reveal + ` </p>`);

  if (myPlayer.character === "Monster") {
    
    if (q3Value === "option2") {
      form.append(`<p> ` + monsterFates[1] + ` </p>`)
    } else if (q4Value === "option1") {
      form.append(`<p> ` + monsterFates[0] + ` </p>`)
    } else {
      form.append(`<p> ` + monsterFates[2] + ` </p>`);
    }
    
  } 
    
  else if (myPlayer.character === "Victor") {
    
    if (score === 15) {
      form.append(`<p> ` + victorFates[0] + ` </p>`);
    } else if (q5Value === "option1") {
      form.append(`<p> ` + victorFates[3] + ` </p>`);
    } else if (q3Value === "option1") {
      form.append(`<p> ` + victorFates[2] + ` </p>`);
    } else if (q4Value === "option1" && q5Value === "option1") {
      form.append(`<p> ` + victorFates[1] + ` </p>`);
    } 
  
}

}

// calculateScore(); //testing
// var submitBtn = $(".submit-btn");
submitBtn.on("click", calculateScore);

// function revealCharacter() {
//   if (myPlayer.character == "Victor") {
//     return "Your character is Victor";
//     // console.log(reveal);
//   } else if (myPlayer.character == "Monster") {
//     return "Your character is the Monster";
//     // console.log(reveal);
//   }
// }


//testing testing 123
// var myBank = initForm(myPlayer);
// console.log(myBank[1]);
// generateForm(myBank);

// revealCharacter();